public enum Naipe {
    Ouro, Copas, Espada, Paus
}
