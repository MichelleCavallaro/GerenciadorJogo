public enum Valor {
    As, Dois, Tres, Quatro, Cinco, Seis, Sete, Dama, Valete, Rei
}
